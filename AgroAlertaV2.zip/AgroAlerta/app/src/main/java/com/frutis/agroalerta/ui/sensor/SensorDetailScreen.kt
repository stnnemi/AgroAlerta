package com.frutis.agroalerta.ui.sensor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.ReadingPoint
import com.frutis.agroalerta.data.model.SensorReading
import com.frutis.agroalerta.data.model.Station
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.SensorIconBox
import com.frutis.agroalerta.ui.components.StatusDot
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.components.color
import com.frutis.agroalerta.ui.components.formatValue
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

@Composable
fun SensorDetailScreen(
    station: Station,
    reading: SensorReading,
    history: List<ReadingPoint>,
    onBack: () -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = reading.type.label, subtitle = station.displayName.uppercase(), onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            WhiteCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SensorIconBox(reading.type, size = 52)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Lectura actual", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text(
                            "${formatValue(reading.value)} ${reading.type.unit}",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(reading.status)
                        Spacer(Modifier.width(6.dp))
                        Text(reading.status.label, color = reading.status.color(), fontWeight = FontWeight.Bold)
                    }
                }
                HorizontalDivider(color = CardBorder)
                InfoRow("Rango operativo", "${formatValue(reading.type.min)} – ${formatValue(reading.type.max)} ${reading.type.unit}")
                InfoRow("Código de sensor", reading.sensorCode)
                InfoRow("Batería", "${reading.battery} %")
                InfoRow("Última actualización", reading.lastUpdate)
                InfoRow("Origen", station.displayName)
            }

            SectionLabel("Últimas 24 horas")
            WhiteCard {
                TrendChart(history, Modifier.fillMaxWidth().height(140.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(history.first().time, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    Text(history.last().time, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }

            SectionLabel("Historial de lecturas")
            WhiteCard {
                history.reversed().forEachIndexed { index, point ->
                    InfoRow(point.time, "${formatValue(point.value)} ${reading.type.unit}")
                    if (index < history.lastIndex) HorizontalDivider(color = CardBorder)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = TextSecondary, modifier = Modifier.weight(1f))
        Text(value, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TrendChart(points: List<ReadingPoint>, modifier: Modifier) {
    val min = points.minOf { it.value }
    val max = points.maxOf { it.value }
    val range = (max - min).takeIf { it > 0 } ?: 1.0
    Canvas(modifier) {
        val stepX = size.width / (points.size - 1)
        val path = Path()
        points.forEachIndexed { i, p ->
            val x = i * stepX
            val y = size.height - ((p.value - min) / range).toFloat() * size.height * 0.85f - size.height * 0.075f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            drawCircle(GreenPrimary, radius = 4.dp.toPx(), center = Offset(x, y))
        }
        drawPath(path, GreenPrimary, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
    }
}
