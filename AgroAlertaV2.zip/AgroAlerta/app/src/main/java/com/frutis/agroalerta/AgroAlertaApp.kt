package com.frutis.agroalerta

import android.app.Application
import com.frutis.agroalerta.data.AppContainer

class AgroAlertaApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
