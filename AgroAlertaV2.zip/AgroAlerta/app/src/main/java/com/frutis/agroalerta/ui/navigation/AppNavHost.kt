package com.frutis.agroalerta.ui.navigation

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.frutis.agroalerta.data.local.UserEntity
import com.frutis.agroalerta.data.local.isSupervisor
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.SensorType
import com.frutis.agroalerta.data.model.Severity
import com.frutis.agroalerta.ui.AppViewModelProvider
import com.frutis.agroalerta.ui.alerts.AlertDetailScreen
import com.frutis.agroalerta.ui.alerts.AlertsScreen
import com.frutis.agroalerta.ui.alerts.AlertsViewModel
import com.frutis.agroalerta.ui.auth.LoginScreen
import com.frutis.agroalerta.ui.auth.RegisterScreen
import com.frutis.agroalerta.ui.auth.SessionViewModel
import com.frutis.agroalerta.ui.auth.SplashScreen
import com.frutis.agroalerta.ui.forms.ChangePasswordScreen
import com.frutis.agroalerta.ui.forms.EditProfileScreen
import com.frutis.agroalerta.ui.forms.FieldReportScreen
import com.frutis.agroalerta.ui.forms.ThresholdsScreen
import com.frutis.agroalerta.ui.history.HistoryScreen
import com.frutis.agroalerta.ui.home.DashboardViewModel
import com.frutis.agroalerta.ui.home.HomeScreen
import com.frutis.agroalerta.ui.notification.CriticalNotificationScreen
import com.frutis.agroalerta.ui.notification.NotificationHelper
import com.frutis.agroalerta.ui.profile.ProfileScreen
import com.frutis.agroalerta.ui.profile.RestrictedScreen
import com.frutis.agroalerta.ui.profile.UsersScreen
import com.frutis.agroalerta.ui.sensor.SensorDetailScreen
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.TextSecondary

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val ALERTS = "alerts"
    const val HISTORY = "history"
    const val PROFILE = "profile"
    const val SENSOR = "sensor/{type}"
    const val ALERT = "alert/{id}"
    const val LOCK = "lock/{id}"
    const val REPORT = "report"
    const val THRESHOLDS = "thresholds"
    const val USERS = "users"
    const val EDIT_PROFILE = "edit_profile"
    const val CHANGE_PASSWORD = "change_password"

    fun sensor(type: SensorType) = "sensor/${type.name}"
    fun alert(id: String) = "alert/$id"
    fun lock(id: String) = "lock/$id"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val supervisorTabs = listOf(
    Tab(Routes.HOME, "Inicio", Icons.Outlined.GridView),
    Tab(Routes.ALERTS, "Alertas", Icons.Outlined.NotificationsNone),
    Tab(Routes.HISTORY, "Historial", Icons.Outlined.History),
    Tab(Routes.PROFILE, "Perfil", Icons.Outlined.Person)
)

private val technicianTabs = listOf(
    Tab(Routes.HOME, "Sensores", Icons.Outlined.Sensors),
    Tab(Routes.PROFILE, "Perfil", Icons.Outlined.Person)
)

/** Rutas a las que el técnico no tiene acceso. */
private val supervisorOnlyRoutes = setOf(
    Routes.ALERTS, Routes.HISTORY, Routes.ALERT, Routes.LOCK, Routes.REPORT, Routes.THRESHOLDS, Routes.USERS
)

@Composable
fun AgroAlertaRoot(
    sessionViewModel: SessionViewModel = viewModel(factory = AppViewModelProvider.Factory)
) {
    val session by sessionViewModel.session.collectAsStateWithLifecycle()
    if (session.restoring) {
        SplashScreen()
    } else {
        AppNavHost(sessionViewModel, session.user)
    }
}

@Composable
private fun AppNavHost(sessionViewModel: SessionViewModel, user: UserEntity?) {
    val navController = rememberNavController()
    val dashboardViewModel: DashboardViewModel = viewModel(factory = AppViewModelProvider.Factory)
    val alertsViewModel: AlertsViewModel = viewModel(factory = AppViewModelProvider.Factory)
    val dashboard by dashboardViewModel.state.collectAsStateWithLifecycle()
    val alerts by alertsViewModel.alerts.collectAsStateWithLifecycle()
    val registeredUsers by sessionViewModel.registeredUsers.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val isSupervisor = user?.isSupervisor == true
    val tabs = if (isSupervisor) supervisorTabs else technicianTabs
    val pendingCount = alerts.count { it.status == AlertStatus.PENDIENTE }

    // Reacciona a cambios de sesión: login/registro lleva al inicio y logout vuelve al login.
    var lastUserId by remember { mutableStateOf(user?.id) }
    LaunchedEffect(user?.id) {
        if (user?.id != lastUserId) {
            lastUserId = user?.id
            val target = if (user != null) Routes.HOME else Routes.LOGIN
            navController.navigate(target) {
                popUpTo(navController.graph.id) { inclusive = true }
            }
        }
    }

    var pendingPushAlertId by remember { mutableStateOf<String?>(null) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val id = pendingPushAlertId ?: return@rememberLauncherForActivityResult
        pendingPushAlertId = null
        alertsViewModel.alert(id)?.let { if (granted) NotificationHelper.showAlert(context, it) }
        if (!granted) Toast.makeText(context, "Permiso de notificaciones denegado", Toast.LENGTH_SHORT).show()
        navController.navigate(Routes.lock(id))
    }

    fun simulatePush(alertId: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !NotificationHelper.hasPermission(context)) {
            pendingPushAlertId = alertId
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            alertsViewModel.alert(alertId)?.let { NotificationHelper.showAlert(context, it) }
            navController.navigate(Routes.lock(alertId))
        }
    }

    fun onBell() {
        val critical = alerts.firstOrNull { it.status == AlertStatus.PENDIENTE && it.severity == Severity.CRITICA }
        if (critical != null) navController.navigate(Routes.lock(critical.id)) else navController.navigateTab(Routes.ALERTS)
    }

    fun acceptAlert(id: String) {
        alertsViewModel.accept(id)
        Toast.makeText(context, "Alerta aceptada · se sincronizará al recuperar cobertura", Toast.LENGTH_SHORT).show()
    }

    // Destino inicial fijo: los cambios de sesión posteriores se manejan navegando.
    val startDestination = remember { if (user != null) Routes.HOME else Routes.LOGIN }
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route
    val showBottomBar = user != null && tabs.any { it.route == currentRoute }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Color.White) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { navController.navigateTab(tab.route) },
                            icon = {
                                if (tab.route == Routes.ALERTS && pendingCount > 0) {
                                    BadgedBox(badge = { Badge() }) { Icon(tab.icon, contentDescription = null) }
                                } else {
                                    Icon(tab.icon, contentDescription = null)
                                }
                            },
                            label = {
                                Text(tab.label, fontWeight = if (currentRoute == tab.route) FontWeight.Bold else FontWeight.Normal)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = GreenDark,
                                selectedTextColor = GreenDark,
                                indicatorColor = GreenSoft,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            composable(Routes.LOGIN) {
                LoginScreen(sessionViewModel, onGoToRegister = { navController.navigate(Routes.REGISTER) })
            }
            composable(Routes.REGISTER) {
                RegisterScreen(sessionViewModel, onBackToLogin = { navController.popBackStack() })
            }
            composable(Routes.HOME) {
                HomeScreen(
                    state = dashboard,
                    isSupervisor = isSupervisor,
                    alerts = alerts,
                    onSelectStation = dashboardViewModel::selectStation,
                    onSensorClick = { navController.navigate(Routes.sensor(it)) },
                    onAlertClick = { navController.navigate(Routes.alert(it)) },
                    onBellClick = ::onBell,
                    onFieldReport = { navController.navigate(Routes.REPORT) },
                    onThresholds = { navController.navigate(Routes.THRESHOLDS) }
                )
            }
            composable(
                Routes.SENSOR,
                arguments = listOf(navArgument("type") { type = NavType.StringType })
            ) { entry ->
                val type = SensorType.valueOf(entry.arguments?.getString("type") ?: SensorType.TEMPERATURA.name)
                val reading = dashboard.readings.first { it.type == type }
                SensorDetailScreen(
                    station = dashboard.station,
                    reading = reading,
                    history = remember(dashboard.station.id, type) { dashboardViewModel.readingHistory(type) },
                    onBack = { navController.popBackStack() }
                )
            }
            supervisorComposable(Routes.ALERTS, isSupervisor, navController) {
                AlertsScreen(
                    alerts = alerts,
                    onAlertClick = { navController.navigate(Routes.alert(it)) },
                    onBellClick = ::onBell
                )
            }
            supervisorComposable(Routes.ALERT, isSupervisor, navController) { id ->
                val alert = alerts.firstOrNull { it.id == id }
                if (alert == null) {
                    LaunchedEffect(Unit) { navController.popBackStack() }
                } else {
                    AlertDetailScreen(
                        alert = alert,
                        relatedReadings = remember(alert.id) { alertsViewModel.relatedReadings(alert) },
                        onBack = { navController.popBackStack() },
                        onAccept = { acceptAlert(alert.id) },
                        onSimulatePush = { simulatePush(alert.id) }
                    )
                }
            }
            supervisorComposable(Routes.LOCK, isSupervisor, navController) { id ->
                val alert = alerts.firstOrNull { it.id == id }
                if (alert == null) {
                    LaunchedEffect(Unit) { navController.popBackStack() }
                } else {
                    CriticalNotificationScreen(
                        alert = alert,
                        onOpenInApp = {
                            navController.navigate(Routes.alert(alert.id)) {
                                popUpTo(Routes.LOCK) { inclusive = true }
                            }
                        },
                        onAccept = {
                            acceptAlert(alert.id)
                            navController.popBackStack()
                        },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
            supervisorComposable(Routes.HISTORY, isSupervisor, navController) {
                HistoryScreen(events = alertsViewModel.history, onBellClick = ::onBell, showBadge = pendingCount > 0)
            }
            supervisorComposable(Routes.REPORT, isSupervisor, navController) {
                FieldReportScreen(dashboard.stations, dashboard.station, onBack = { navController.popBackStack() })
            }
            supervisorComposable(Routes.THRESHOLDS, isSupervisor, navController) {
                ThresholdsScreen(dashboard.station, onBack = { navController.popBackStack() })
            }
            supervisorComposable(Routes.USERS, isSupervisor, navController) {
                UsersScreen(registeredUsers, onBack = { navController.popBackStack() })
            }
            composable(Routes.PROFILE) {
                if (user != null) {
                    ProfileScreen(
                        user = user,
                        onEditProfile = { navController.navigate(Routes.EDIT_PROFILE) },
                        onChangePassword = { navController.navigate(Routes.CHANGE_PASSWORD) },
                        onUsers = { navController.navigate(Routes.USERS) },
                        onLogout = sessionViewModel::logout
                    )
                } else {
                    Box(Modifier.fillMaxSize())
                }
            }
            composable(Routes.EDIT_PROFILE) {
                EditProfileScreen(user?.fullName.orEmpty(), user?.email.orEmpty(), onBack = { navController.popBackStack() })
            }
            composable(Routes.CHANGE_PASSWORD) {
                ChangePasswordScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}

/** Destino visible solo para supervisores; el técnico ve una pantalla de acceso restringido. */
private fun androidx.navigation.NavGraphBuilder.supervisorComposable(
    route: String,
    isSupervisor: Boolean,
    navController: NavHostController,
    content: @Composable (id: String?) -> Unit
) {
    check(route in supervisorOnlyRoutes)
    val arguments = if (route.contains("{id}")) listOf(navArgument("id") { type = NavType.StringType }) else emptyList()
    composable(route, arguments = arguments) { entry ->
        if (isSupervisor) {
            content(entry.arguments?.getString("id"))
        } else {
            RestrictedScreen(onBack = { navController.popBackStack() })
        }
    }
}

private fun NavHostController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}
