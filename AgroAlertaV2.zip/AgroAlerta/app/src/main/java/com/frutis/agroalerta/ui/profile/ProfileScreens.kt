package com.frutis.agroalerta.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.local.UserEntity
import com.frutis.agroalerta.data.local.isSupervisor
import com.frutis.agroalerta.data.local.roleEnum
import com.frutis.agroalerta.data.model.Role
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.Tag
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.theme.BlueIcon
import com.frutis.agroalerta.ui.theme.BlueSoft
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedAlert
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RoleTag(role: Role) {
    if (role == Role.SUPERVISOR) Tag(role.label, GreenSoft, GreenDark) else Tag(role.label, BlueSoft, BlueIcon)
}

@Composable
private fun Avatar(name: String, size: Int) {
    Box(
        Modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(GreenPrimary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() },
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size / 2.6).sp
        )
    }
}

@Composable
fun ProfileScreen(
    user: UserEntity,
    onEditProfile: () -> Unit,
    onChangePassword: () -> Unit,
    onUsers: () -> Unit,
    onLogout: () -> Unit
) {
    var confirmLogout by rememberSaveable { mutableStateOf(false) }
    var showNotificationSettings by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Mi perfil")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            WhiteCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(user.fullName, 60)
                    Spacer(Modifier.width(14.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(user.fullName, style = MaterialTheme.typography.titleMedium)
                        Text(user.email, color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                        RoleTag(user.roleEnum)
                    }
                }
                HorizontalDivider(color = CardBorder)
                Text("Permisos", fontWeight = FontWeight.Bold)
                Text(user.roleEnum.description, color = TextSecondary)
            }

            SectionLabel("Cuenta")
            WhiteCard {
                MenuRow(Icons.Outlined.Edit, "Editar perfil", onEditProfile)
                HorizontalDivider(color = CardBorder)
                MenuRow(Icons.Outlined.Key, "Cambiar contraseña", onChangePassword)
                if (user.isSupervisor) {
                    HorizontalDivider(color = CardBorder)
                    MenuRow(Icons.Outlined.NotificationsActive, "Preferencias de notificación") { showNotificationSettings = true }
                    HorizontalDivider(color = CardBorder)
                    MenuRow(Icons.Outlined.Group, "Usuarios registrados", onUsers)
                }
            }

            WhiteCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = GreenPrimary)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Tu cuenta se almacena localmente en SQLite con contraseña cifrada (SHA-256 con sal).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            Button(
                onClick = { confirmLogout = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RedAlert),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Cerrar sesión", fontWeight = FontWeight.Bold)
            }
            Text(
                "AgroAlerta v1.0.0 · MVP DSY1105",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text("Cerrar sesión") },
            text = { Text("¿Deseas cerrar tu sesión en este dispositivo?") },
            confirmButton = {
                TextButton(onClick = { confirmLogout = false; onLogout() }) { Text("Cerrar sesión", color = RedAlert) }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("Cancelar") } }
        )
    }
    if (showNotificationSettings) {
        FutureUpdateDialog(onDismiss = { showNotificationSettings = false })
    }
}

@Composable
private fun MenuRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = GreenPrimary)
        Spacer(Modifier.width(12.dp))
        Text(label, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextSecondary)
    }
}

/** Lista de cuentas guardadas en la base de datos local (visible solo para supervisores). */
@Composable
fun UsersScreen(users: List<UserEntity>, onBack: () -> Unit) {
    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Usuarios registrados", onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel("Base de datos local · ${users.size} cuentas")
            users.forEach { user ->
                WhiteCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(user.fullName, 44)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(user.fullName, fontWeight = FontWeight.Bold)
                            Text(user.email, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            Text(
                                "Alta: ${dateFormat.format(Date(user.createdAt))}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        RoleTag(user.roleEnum)
                    }
                }
            }
        }
    }
}

/** Se muestra si un técnico intenta abrir una sección exclusiva del supervisor. */
@Composable
fun RestrictedScreen(onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Acceso restringido", onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Outlined.Lock, contentDescription = null, tint = GreenPrimary, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(12.dp))
            Text("Sección exclusiva para supervisores", style = MaterialTheme.typography.titleMedium)
            Text(
                "Tu perfil de técnico permite consultar únicamente el estado de los sensores.",
                color = TextSecondary
            )
        }
    }
}
