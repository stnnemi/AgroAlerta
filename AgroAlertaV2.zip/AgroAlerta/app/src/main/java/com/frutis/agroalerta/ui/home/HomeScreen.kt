package com.frutis.agroalerta.ui.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Opacity
import androidx.compose.material.icons.outlined.Plumbing
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.Actuator
import com.frutis.agroalerta.data.model.ActuatorType
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.SensorReading

import com.frutis.agroalerta.data.model.SensorType
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.CacheBanner
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.SensorCard
import com.frutis.agroalerta.ui.components.SensorIconBox
import com.frutis.agroalerta.ui.components.StatusDot
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.components.color
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedAlert
import com.frutis.agroalerta.ui.theme.RedBorder
import com.frutis.agroalerta.ui.theme.RedSoft
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

/**
 * Pantalla principal "Estado del predio".
 * - Supervisor: alertas activas, telemetría completa, actuadores y accesos a formularios.
 * - Técnico: solo el estado de los sensores (lectura).
 */
@Composable
fun HomeScreen(
    state: DashboardState,
    isSupervisor: Boolean,
    alerts: List<Alert>,
    onSelectStation: (String) -> Unit,
    onSensorClick: (SensorType) -> Unit,
    onAlertClick: (String) -> Unit,
    onBellClick: () -> Unit,
    onFieldReport: () -> Unit,
    onThresholds: () -> Unit
) {
    var showStationPicker by rememberSaveable { mutableStateOf(false) }
    var showFutureUpdate by rememberSaveable { mutableStateOf(false) }

    val activeAlerts = alerts.filter { it.status == AlertStatus.PENDIENTE && it.stationId == state.station.id }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(
            title = if (isSupervisor) "Estado del predio" else "Estado de sensores",
            onBellClick = if (isSupervisor) onBellClick else null,
            showBellBadge = alerts.any { it.status == AlertStatus.PENDIENTE }
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CacheBanner(lastSync = state.lastSync, offline = state.offline)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SectionLabel("Estación activa")
                    Text(state.station.displayName, style = MaterialTheme.typography.headlineSmall)
                }
                OutlinedButton(
                    onClick = { showStationPicker = true },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBDBDBD))
                ) {
                    Text("Cambiar", color = GreenDark, fontWeight = FontWeight.Bold)
                    Icon(Icons.Outlined.KeyboardArrowDown, contentDescription = null, tint = GreenDark, modifier = Modifier.size(18.dp))
                }
            }

            if (isSupervisor) {
                if (activeAlerts.isNotEmpty()) {
                    ActiveAlertCard(activeAlerts, onClick = { onAlertClick(activeAlerts.first().id) })
                } else {
                    NoAlertsCard()
                }
            } else {
                TechnicianNotice()
            }

            Row(verticalAlignment = Alignment.Bottom) {
                Column(Modifier.weight(1f)) {
                    SectionLabel("Telemetría")
                    Text("Lecturas en tiempo real", style = MaterialTheme.typography.headlineSmall)
                }
                LiveBadge()
            }
            SensorGrid(state.readings, onSensorClick)

            if (isSupervisor) {
                Column {
                    SectionLabel("Control")
                    Text("Estado de actuadores", style = MaterialTheme.typography.headlineSmall)
                }
                WhiteCard {
                    state.actuators.forEachIndexed { index, actuator ->
                        ActuatorRow(actuator, onToggle = { showFutureUpdate = true })
                        if (index < state.actuators.lastIndex) HorizontalDivider(color = CardBorder)
                    }
                }

                Column {
                    SectionLabel("Gestión")
                    Text("Acciones rápidas", style = MaterialTheme.typography.headlineSmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    QuickAction("Reporte en terreno", Icons.Outlined.Description, Modifier.weight(1f), onFieldReport)
                    QuickAction("Configurar umbrales", Icons.Outlined.Tune, Modifier.weight(1f), onThresholds)
                }
            } else {
                Column {
                    SectionLabel("Diagnóstico")
                    Text("Estado de sensores", style = MaterialTheme.typography.headlineSmall)
                }
                WhiteCard {
                    state.readings.forEachIndexed { index, reading ->
                        SensorStatusRow(reading, onClick = { onSensorClick(reading.type) })
                        if (index < state.readings.lastIndex) HorizontalDivider(color = CardBorder)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showStationPicker) {
        AlertDialog(
            onDismissRequest = { showStationPicker = false },
            title = { Text("Seleccionar estación") },
            text = {
                Column {
                    state.stations.forEach { station ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onSelectStation(station.id)
                                    showStationPicker = false
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = station.id == state.station.id, onClick = null)
                            Spacer(Modifier.width(8.dp))
                            Text(station.displayName)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showStationPicker = false }) { Text("Cerrar") } }
        )
    }
    if (showFutureUpdate) {
        FutureUpdateDialog(
            onDismiss = { showFutureUpdate = false },
            detail = "El control remoto de actuadores estará disponible en una futura actualización, " +
                "a través de la API de la plataforma de supervisión."
        )
    }
}

@Composable
private fun ActiveAlertCard(alerts: List<Alert>, onClick: () -> Unit) {
    val alert = alerts.first()
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = RedSoft),
        border = BorderStroke(1.dp, RedBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(5.dp)
                    .height(96.dp)
                    .background(RedAlert)
            )
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(RedAlert),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.AcUnit, contentDescription = null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "${alerts.size} ALERTA${if (alerts.size > 1) "S" else ""} ACTIVA${if (alerts.size > 1) "S" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = RedText
                    )
                    Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = RedText)
                    Text("${alert.location} · ${alert.dayLabel} ${alert.time}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Ver alerta", tint = RedText)
            }
        }
    }
}

@Composable
private fun NoAlertsCard() {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GreenSoft,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = GreenPrimary)
            Spacer(Modifier.width(10.dp))
            Text("Sin alertas activas en esta estación", color = GreenDark, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun TechnicianNotice() {
    Surface(shape = RoundedCornerShape(14.dp), color = Color.White, border = BorderStroke(1.dp, CardBorder), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Visibility, contentDescription = null, tint = GreenPrimary)
            Spacer(Modifier.width(10.dp))
            Text(
                "Perfil técnico: acceso de solo lectura al estado de los sensores.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun LiveBadge() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(GreenPrimary)
        )
        Spacer(Modifier.width(6.dp))
        Text("EN VIVO", style = MaterialTheme.typography.labelSmall, color = GreenDark)
    }
}

@Composable
private fun SensorGrid(readings: List<SensorReading>, onSensorClick: (SensorType) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        readings.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { reading ->
                    SensorCard(
                        reading = reading,
                        onClick = { onSensorClick(reading.type) },
                        modifier = Modifier
                            .weight(1f)
                            .height(92.dp)
                    )
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

private fun ActuatorType.icon(): ImageVector = when (this) {
    ActuatorType.ELECTROVALVULA -> Icons.Outlined.Opacity
    ActuatorType.BOMBA -> Icons.Outlined.Plumbing
    ActuatorType.ANTIHELADA -> Icons.Outlined.AcUnit
}

@Composable
private fun ActuatorRow(actuator: Actuator, onToggle: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (actuator.isOn) GreenSoft else Color(0xFFF0F0F0)),
            contentAlignment = Alignment.Center
        ) {
            Icon(actuator.type.icon(), contentDescription = null, tint = if (actuator.isOn) GreenPrimary else TextSecondary)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(actuator.name, fontWeight = FontWeight.Medium)
            Text(
                (if (actuator.isOn) "Encendido · " else "Apagado · ") + actuator.detail,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        Switch(
            checked = actuator.isOn,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(checkedTrackColor = GreenPrimary)
        )
    }
}

@Composable
private fun SensorStatusRow(reading: SensorReading, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SensorIconBox(reading.type, size = 36)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(reading.type.label, fontWeight = FontWeight.Medium)
            Text(
                "${reading.sensorCode} · Batería ${reading.battery}% · ${reading.lastUpdate}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
        StatusDot(reading.status)
        Spacer(Modifier.width(6.dp))
        Text(reading.status.label, style = MaterialTheme.typography.bodySmall, color = reading.status.color())
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder),
        modifier = modifier.height(96.dp)
    ) {
        Column(Modifier.fillMaxHeight().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, contentDescription = null, tint = GreenPrimary)
            Text(label, fontWeight = FontWeight.Bold, color = GreenDark)
        }
    }
}

