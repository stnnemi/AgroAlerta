package com.frutis.agroalerta.data

import android.database.sqlite.SQLiteConstraintException
import com.frutis.agroalerta.data.local.UserDao
import com.frutis.agroalerta.data.local.UserEntity
import com.frutis.agroalerta.data.model.Role
import kotlinx.coroutines.flow.Flow

class AuthException(message: String) : Exception(message)

class AuthRepository(
    private val userDao: UserDao,
    private val sessionManager: SessionManager
) {

    val users: Flow<List<UserEntity>> = userDao.observeAll()

    suspend fun login(email: String, password: String): Result<UserEntity> = runCatching {
        val user = userDao.findByEmail(email.trim().lowercase())
            ?: throw AuthException("No existe una cuenta con ese correo")
        if (!PasswordHasher.verify(password, user.salt, user.passwordHash)) {
            throw AuthException("Contraseña incorrecta")
        }
        sessionManager.loggedUserId = user.id
        user
    }

    suspend fun register(
        fullName: String,
        email: String,
        password: String,
        role: Role
    ): Result<UserEntity> = runCatching {
        val normalizedEmail = email.trim().lowercase()
        if (userDao.findByEmail(normalizedEmail) != null) {
            throw AuthException("Ya existe una cuenta con ese correo")
        }
        val salt = PasswordHasher.newSalt()
        val user = UserEntity(
            fullName = fullName.trim(),
            email = normalizedEmail,
            passwordHash = PasswordHasher.hash(password, salt),
            salt = salt,
            role = role.name
        )
        val id = try {
            userDao.insert(user)
        } catch (e: SQLiteConstraintException) {
            throw AuthException("Ya existe una cuenta con ese correo")
        }
        sessionManager.loggedUserId = id
        user.copy(id = id)
    }

    suspend fun currentUser(): UserEntity? =
        sessionManager.loggedUserId?.let { userDao.findById(it) }

    fun logout() {
        sessionManager.loggedUserId = null
    }
}
