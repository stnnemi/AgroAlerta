package com.frutis.agroalerta.ui

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.frutis.agroalerta.AgroAlertaApp
import com.frutis.agroalerta.ui.alerts.AlertsViewModel
import com.frutis.agroalerta.ui.auth.SessionViewModel
import com.frutis.agroalerta.ui.home.DashboardViewModel

object AppViewModelProvider {
    val Factory: ViewModelProvider.Factory = viewModelFactory {
        initializer { SessionViewModel(app().container.authRepository) }
        initializer { DashboardViewModel(app().container.telemetryRepository) }
        initializer { AlertsViewModel(app().container.telemetryRepository) }
    }
}

private fun CreationExtras.app(): AgroAlertaApp = this[APPLICATION_KEY] as AgroAlertaApp
