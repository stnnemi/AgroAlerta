package com.frutis.agroalerta.ui.forms

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.frutis.agroalerta.data.model.SensorType
import com.frutis.agroalerta.data.model.Station
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.components.formatValue
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

/**
 * Estructura común de los formularios del MVP: validan los datos ingresados y, como aún no
 * existe conexión con la plataforma central, informan "Para una futura actualización".
 */
@Composable
private fun FormScaffold(
    title: String,
    description: String,
    submitLabel: String,
    onBack: () -> Unit,
    validate: () -> String?,
    content: @Composable ColumnScope.() -> Unit
) {
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    var showFutureUpdate by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = title, onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(description, color = TextSecondary)
            WhiteCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    content()
                }
            }
            error?.let { Text(it, color = RedText) }
            Button(
                onClick = {
                    error = validate()
                    if (error == null) showFutureUpdate = true
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(submitLabel, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showFutureUpdate) {
        FutureUpdateDialog(onDismiss = { showFutureUpdate = false })
    }
}

@Composable
private fun FormField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    minLines: Int = 1,
    password: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        minLines = minLines,
        singleLine = minLines == 1,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun <T> ChipSelector(options: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = GreenPrimary,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

private val reportTypes = listOf("Inspección rutinaria", "Falla de sensor", "Daño por helada", "Fuga en línea", "Otro")

/** Reporte de revisión en terreno asociado a un cuartel (y opcionalmente a la ubicación). */
@Composable
fun FieldReportScreen(stations: List<Station>, initialStation: Station, onBack: () -> Unit) {
    var station by rememberSaveable { mutableStateOf(initialStation.id) }
    var type by rememberSaveable { mutableStateOf<String?>(null) }
    var notes by rememberSaveable { mutableStateOf("") }
    var attachLocation by rememberSaveable { mutableStateOf(true) }
    var showLocation by rememberSaveable { mutableStateOf(false) }

    FormScaffold(
        title = "Reporte en terreno",
        description = "Registra una revisión realizada en el predio para mantener la trazabilidad de las acciones.",
        submitLabel = "Enviar reporte",
        onBack = onBack,
        validate = {
            when {
                type == null -> "Selecciona el tipo de reporte"
                notes.trim().length < 10 -> "Describe la revisión (mínimo 10 caracteres)"
                else -> null
            }
        }
    ) {
        Text("Cuartel / estación", fontWeight = FontWeight.Bold)
        ChipSelector(stations.map { it.id }, station, { id -> stations.first { it.id == id }.displayName }) { station = it }
        Text("Tipo de reporte", fontWeight = FontWeight.Bold)
        ChipSelector(reportTypes, type, { it }) { type = it }
        FormField(notes, { notes = it }, "Descripción de la revisión", minLines = 4)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Adjuntar ubicación", fontWeight = FontWeight.Bold)
                Text("Asocia el reporte a tu posición actual", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Switch(
                checked = attachLocation,
                onCheckedChange = { attachLocation = it },
                colors = SwitchDefaults.colors(checkedTrackColor = GreenPrimary)
            )
        }
        if (attachLocation) {
            OutlinedButton(onClick = { showLocation = true }, shape = RoundedCornerShape(12.dp)) {
                Icon(Icons.Outlined.MyLocation, contentDescription = null, tint = GreenDark)
                Spacer(Modifier.width(8.dp))
                Text("Obtener ubicación", color = GreenDark)
            }
        }
    }

    if (showLocation) {
        FutureUpdateDialog(
            onDismiss = { showLocation = false },
            detail = "La captura de ubicación GPS se incorporará en una futura actualización."
        )
    }
}

/** Configuración de umbrales de alerta por sensor (solo supervisor). */
@Composable
fun ThresholdsScreen(station: Station, onBack: () -> Unit) {
    var sensor by rememberSaveable { mutableStateOf(SensorType.TEMPERATURA) }
    var min by rememberSaveable(sensor) { mutableStateOf(formatValue(sensor.min)) }
    var max by rememberSaveable(sensor) { mutableStateOf(formatValue(sensor.max)) }
    var notify by rememberSaveable { mutableStateOf(true) }

    FormScaffold(
        title = "Configurar umbrales",
        description = "Define los límites que disparan alertas en ${station.displayName}.",
        submitLabel = "Guardar umbrales",
        onBack = onBack,
        validate = {
            val minValue = min.replace(',', '.').toDoubleOrNull()
            val maxValue = max.replace(',', '.').toDoubleOrNull()
            when {
                minValue == null || maxValue == null -> "Ingresa valores numéricos válidos"
                minValue >= maxValue -> "El mínimo debe ser menor que el máximo"
                else -> null
            }
        }
    ) {
        Text("Sensor", fontWeight = FontWeight.Bold)
        ChipSelector(SensorType.entries, sensor, { it.label }) { sensor = it }
        FormField(min, { min = it }, "Mínimo (${sensor.unit})", KeyboardType.Decimal)
        FormField(max, { max = it }, "Máximo (${sensor.unit})", KeyboardType.Decimal)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Notificación push al superar el umbral", modifier = Modifier.weight(1f))
            Switch(
                checked = notify,
                onCheckedChange = { notify = it },
                colors = SwitchDefaults.colors(checkedTrackColor = GreenPrimary)
            )
        }
    }
}

@Composable
fun EditProfileScreen(currentName: String, currentEmail: String, onBack: () -> Unit) {
    var name by rememberSaveable { mutableStateOf(currentName) }
    var phone by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf(currentEmail) }

    FormScaffold(
        title = "Editar perfil",
        description = "Actualiza tus datos de contacto para la coordinación ante alertas.",
        submitLabel = "Guardar cambios",
        onBack = onBack,
        validate = {
            when {
                name.trim().length < 3 -> "Ingresa tu nombre completo"
                !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "El correo no es válido"
                phone.isNotBlank() && phone.filter { it.isDigit() }.length < 8 -> "El teléfono no es válido"
                else -> null
            }
        }
    ) {
        FormField(name, { name = it }, "Nombre completo")
        FormField(email, { email = it }, "Correo electrónico", KeyboardType.Email)
        FormField(phone, { phone = it }, "Teléfono (opcional)", KeyboardType.Phone)
    }
}

@Composable
fun ChangePasswordScreen(onBack: () -> Unit) {
    var current by rememberSaveable { mutableStateOf("") }
    var new by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }

    FormScaffold(
        title = "Cambiar contraseña",
        description = "Por seguridad, la nueva contraseña debe tener al menos 6 caracteres.",
        submitLabel = "Actualizar contraseña",
        onBack = onBack,
        validate = {
            when {
                current.isBlank() -> "Ingresa tu contraseña actual"
                new.length < 6 -> "La nueva contraseña debe tener al menos 6 caracteres"
                new != confirm -> "Las contraseñas no coinciden"
                else -> null
            }
        }
    ) {
        FormField(current, { current = it }, "Contraseña actual", KeyboardType.Password, password = true)
        FormField(new, { new = it }, "Nueva contraseña", KeyboardType.Password, password = true)
        FormField(confirm, { confirm = it }, "Confirmar nueva contraseña", KeyboardType.Password, password = true)
    }
}
