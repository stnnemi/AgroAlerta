package com.frutis.agroalerta.ui.theme

import androidx.compose.ui.graphics.Color

val GreenDark = Color(0xFF1E5B1E)
val GreenPrimary = Color(0xFF2E7D32)
val GreenAccent = Color(0xFF388E3C)
val GreenSoft = Color(0xFFE4F2E3)
val GreenBorder = Color(0xFFB9DDB7)

val RedAlert = Color(0xFFD32F2F)
val RedText = Color(0xFFB71C1C)
val RedSoft = Color(0xFFFDE6E6)
val RedBorder = Color(0xFFF5B5B5)

val AmberAlert = Color(0xFFF2A900)
val AmberText = Color(0xFF8A5A00)
val AmberSoft = Color(0xFFFFF4D6)

val BlueIcon = Color(0xFF1E88E5)
val BlueSoft = Color(0xFFE3F0FB)

val ScreenBg = Color(0xFFF3F3F3)
val CardBorder = Color(0xFFE2E2E2)
val TextPrimary = Color(0xFF1B1B1B)
val TextSecondary = Color(0xFF6B6B6B)
