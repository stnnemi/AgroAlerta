package com.frutis.agroalerta.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frutis.agroalerta.data.TelemetryRepository
import com.frutis.agroalerta.data.model.Actuator
import com.frutis.agroalerta.data.model.SensorReading
import com.frutis.agroalerta.data.model.Station
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class DashboardState(
    val stations: List<Station>,
    val station: Station,
    val readings: List<SensorReading>,
    val actuators: List<Actuator>,
    val lastSync: String,
    val offline: Boolean = true
)

class DashboardViewModel(private val repository: TelemetryRepository) : ViewModel() {

    private val _state = MutableStateFlow(buildState(repository.station("c3")))
    val state: StateFlow<DashboardState> = _state.asStateFlow()

    init {
        // Simula lecturas "en vivo" con pequeñas variaciones sobre la última lectura en caché.
        viewModelScope.launch {
            while (true) {
                delay(5_000)
                val stationId = _state.value.station.id
                _state.update {
                    it.copy(readings = repository.readings(stationId) { type ->
                        (type.max - type.min) * Random.nextDouble(-0.01, 0.01)
                    })
                }
            }
        }
    }

    fun selectStation(stationId: String) {
        _state.value = buildState(repository.station(stationId))
    }

    fun readingHistory(type: com.frutis.agroalerta.data.model.SensorType) =
        repository.readingHistory(_state.value.station.id, type)

    private fun buildState(station: Station) = DashboardState(
        stations = repository.stations,
        station = station,
        readings = repository.readings(station.id),
        actuators = repository.actuators(station.id),
        lastSync = repository.lastSync
    )
}
