package com.frutis.agroalerta.data

import android.content.Context

/** Recuerda el usuario autenticado entre aperturas de la app (solo el id, nunca la contraseña). */
class SessionManager(context: Context) {

    private val prefs = context.getSharedPreferences("agroalerta_session", Context.MODE_PRIVATE)

    var loggedUserId: Long?
        get() = prefs.getLong(KEY_USER_ID, NO_USER).takeIf { it != NO_USER }
        set(value) {
            prefs.edit().apply {
                if (value == null) remove(KEY_USER_ID) else putLong(KEY_USER_ID, value)
            }.apply()
        }

    private companion object {
        const val KEY_USER_ID = "logged_user_id"
        const val NO_USER = -1L
    }
}
