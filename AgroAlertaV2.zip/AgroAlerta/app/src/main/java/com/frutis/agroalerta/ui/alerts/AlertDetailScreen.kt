package com.frutis.agroalerta.ui.alerts

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.SensorReading
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.SensorIconBox
import com.frutis.agroalerta.ui.components.SeverityTag
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.components.colors
import com.frutis.agroalerta.ui.components.formatValue
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

private val actionOptions = listOf("Revisión en terreno", "Anti-heladas activado", "Válvula cerrada", "Riego ajustado", "Otro")

@Composable
fun AlertDetailScreen(
    alert: Alert,
    relatedReadings: List<SensorReading>,
    onBack: () -> Unit,
    onAccept: () -> Unit,
    onSimulatePush: () -> Unit
) {
    var action by rememberSaveable { mutableStateOf<String?>(null) }
    var notes by rememberSaveable { mutableStateOf("") }
    var formError by rememberSaveable { mutableStateOf<String?>(null) }
    var showFutureUpdate by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Detalle de alerta", onBack = onBack)
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            WhiteCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val (bg, fg) = alert.severity.colors()
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(bg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(alert.category.icon(), contentDescription = null, tint = fg)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SeverityTag(alert.severity)
                            StatusTag(alert.status)
                        }
                        Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.LocationOn, null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                    Text(" ${alert.location}", color = TextSecondary)
                    Spacer(Modifier.width(16.dp))
                    Icon(Icons.Outlined.Schedule, null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                    Text(" ${alert.dayLabel} · ${alert.time}", color = TextSecondary)
                }
                HorizontalDivider(color = CardBorder)
                Text("Descripción", fontWeight = FontWeight.Bold)
                Text(alert.description, color = TextSecondary)
                Text("Recomendación", fontWeight = FontWeight.Bold)
                Text(alert.recommendation, color = TextSecondary)
            }

            if (relatedReadings.isNotEmpty()) {
                SectionLabel("Lecturas asociadas")
                WhiteCard {
                    relatedReadings.forEach { r ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SensorIconBox(r.type, size = 34)
                            Spacer(Modifier.width(10.dp))
                            Text(r.type.label, modifier = Modifier.weight(1f))
                            Text("${formatValue(r.value)} ${r.type.unit}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (alert.status == AlertStatus.PENDIENTE) {
                Button(
                    onClick = onAccept,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Aceptar alerta", fontWeight = FontWeight.Bold)
                }
            }
            OutlinedButton(
                onClick = onSimulatePush,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Icon(Icons.Outlined.NotificationsActive, contentDescription = null, tint = GreenDark)
                Spacer(Modifier.width(8.dp))
                Text("Simular notificación push", color = GreenDark)
            }

            SectionLabel("Trazabilidad")
            WhiteCard {
                Text("Registrar acción tomada", style = MaterialTheme.typography.titleMedium)
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    actionOptions.forEach { option ->
                        FilterChip(
                            selected = action == option,
                            onClick = { action = option; formError = null },
                            label = { Text(option) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = GreenPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it; formError = null },
                    label = { Text("Observaciones") },
                    minLines = 3,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                formError?.let { Text(it, color = RedText, style = MaterialTheme.typography.bodySmall) }
                Button(
                    onClick = {
                        formError = when {
                            action == null -> "Selecciona la acción realizada"
                            notes.isBlank() -> "Agrega una observación"
                            else -> null
                        }
                        if (formError == null) showFutureUpdate = true
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Guardar acción")
                }
            }
        }
    }

    if (showFutureUpdate) {
        FutureUpdateDialog(onDismiss = { showFutureUpdate = false })
    }
}
