package com.frutis.agroalerta.ui.alerts

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AcUnit
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Plumbing
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.Waves
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.data.model.AlertCategory
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.Severity
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.SeverityTag
import com.frutis.agroalerta.ui.components.Tag
import com.frutis.agroalerta.ui.components.colors
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedAlert
import com.frutis.agroalerta.ui.theme.RedSoft
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

fun AlertCategory.icon(): ImageVector = when (this) {
    AlertCategory.HELADA -> Icons.Outlined.AcUnit
    AlertCategory.FUGA -> Icons.Outlined.Plumbing
    AlertCategory.NIVEL_AGUA -> Icons.Outlined.Waves
    AlertCategory.SENSOR -> Icons.Outlined.Sensors
    AlertCategory.SISTEMA -> Icons.Outlined.Info
}

@Composable
fun AlertsScreen(
    alerts: List<Alert>,
    onAlertClick: (String) -> Unit,
    onBellClick: () -> Unit
) {
    var severity by rememberSaveable { mutableStateOf(Severity.CRITICA) }
    var category by rememberSaveable { mutableStateOf<AlertCategory?>(null) }
    val pendingCount = alerts.count { it.status == AlertStatus.PENDIENTE }
    val filtered = alerts.filter { it.severity == severity && (category == null || it.category == category) }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Alertas e historial", onBellClick = onBellClick, showBellBadge = pendingCount > 0)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    SectionLabel("Centro de eventos")
                    Text("Alertas del predio", style = MaterialTheme.typography.headlineSmall)
                }
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(RedAlert),
                    contentAlignment = Alignment.Center
                ) {
                    Text(pendingCount.toString(), color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Severity.entries.forEach { s ->
                    val selected = s == severity
                    FilterChip(
                        selected = selected,
                        onClick = { severity = s },
                        label = { Text(if (s == Severity.CRITICA) "Críticas" else if (s == Severity.ADVERTENCIA) "Advertencias" else "Informativas") },
                        shape = RoundedCornerShape(50),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = RedAlert,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White
                        )
                    )
                }
            }
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(AlertCategory.HELADA, AlertCategory.FUGA, AlertCategory.NIVEL_AGUA).forEach { c ->
                    val selected = category == c
                    FilterChip(
                        selected = selected,
                        onClick = { category = if (selected) null else c },
                        label = { Text(c.label, fontSize = 11.sp) },
                        shape = RoundedCornerShape(8.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = RedSoft.copy(alpha = 0.6f),
                            labelColor = RedText,
                            selectedContainerColor = RedText,
                            selectedLabelColor = Color.White
                        ),
                        border = null
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    when (severity) {
                        Severity.CRITICA -> "Eventos críticos"
                        Severity.ADVERTENCIA -> "Advertencias"
                        Severity.INFORMATIVA -> "Eventos informativos"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                Text("Más recientes primero", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }

            if (filtered.isEmpty()) {
                Text(
                    "No hay eventos para este filtro.",
                    color = TextSecondary,
                    modifier = Modifier.padding(vertical = 24.dp)
                )
            }
            filtered.forEach { AlertCard(it, onClick = { onAlertClick(it.id) }) }

            OfflineNotice()
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun AlertCard(alert: Alert, onClick: () -> Unit) {
    val (iconBg, iconFg) = alert.severity.colors()
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(alert.category.icon(), contentDescription = null, tint = iconFg)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SeverityTag(alert.severity)
                    StatusTag(alert.status)
                }
                Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconLine(Icons.Outlined.LocationOn, alert.location)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconLine(Icons.Outlined.Schedule, "${alert.dayLabel} · ${alert.time}")
                    if (alert.cachedLocally) {
                        Spacer(Modifier.width(8.dp))
                        Tag("Caché local", GreenSoft, GreenDark, bold = false, icon = Icons.Outlined.CloudOff)
                    }
                }
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextSecondary)
        }
    }
}

@Composable
fun StatusTag(status: AlertStatus) {
    if (status == AlertStatus.PENDIENTE) {
        Tag(status.label, Color(0xFFF7C9C9), RedText, bold = false)
    } else {
        Tag(status.label, GreenSoft, GreenDark, bold = false)
    }
}

@Composable
private fun IconLine(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
private fun OfflineNotice() {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, GreenBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = GreenDark)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Datos disponibles sin conexión", fontWeight = FontWeight.Bold, color = GreenDark, fontSize = 13.sp)
                Text(
                    "Los eventos se sincronizarán al recuperar cobertura.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}
