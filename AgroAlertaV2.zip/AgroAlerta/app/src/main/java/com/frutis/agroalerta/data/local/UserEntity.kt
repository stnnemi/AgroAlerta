package com.frutis.agroalerta.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.frutis.agroalerta.data.model.Role

@Entity(tableName = "users", indices = [Index(value = ["email"], unique = true)])
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "full_name") val fullName: String,
    val email: String,
    @ColumnInfo(name = "password_hash") val passwordHash: String,
    val salt: String,
    val role: String,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis()
)

val UserEntity.roleEnum: Role get() = Role.fromName(role)

val UserEntity.isSupervisor: Boolean get() = roleEnum == Role.SUPERVISOR
