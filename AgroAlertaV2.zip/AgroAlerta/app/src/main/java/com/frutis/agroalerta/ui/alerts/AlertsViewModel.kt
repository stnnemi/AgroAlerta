package com.frutis.agroalerta.ui.alerts

import androidx.lifecycle.ViewModel
import com.frutis.agroalerta.data.TelemetryRepository
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.HistoryEvent
import com.frutis.agroalerta.data.model.SensorReading
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AlertsViewModel(private val repository: TelemetryRepository) : ViewModel() {

    private val _alerts = MutableStateFlow(repository.alerts)
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()

    val history: List<HistoryEvent> = repository.history

    fun alert(id: String): Alert? = _alerts.value.firstOrNull { it.id == id }

    /** Últimas lecturas de la estación de origen para los sensores involucrados en la alerta. */
    fun relatedReadings(alert: Alert): List<SensorReading> =
        repository.readings(alert.stationId).filter { it.type in alert.relatedSensors }

    /** Marca la alerta como atendida en la sesión actual (aún sin sincronizar con la plataforma). */
    fun accept(id: String) {
        _alerts.update { list ->
            list.map { if (it.id == id) it.copy(status = AlertStatus.ATENDIDA) else it }
        }
    }
}
