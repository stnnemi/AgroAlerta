package com.frutis.agroalerta.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Thermostat
import androidx.compose.material.icons.outlined.WaterDrop
import androidx.compose.material.icons.outlined.Waves
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.SensorReading
import com.frutis.agroalerta.data.model.SensorStatus
import com.frutis.agroalerta.data.model.SensorType
import com.frutis.agroalerta.data.model.Severity
import com.frutis.agroalerta.ui.theme.AmberAlert
import com.frutis.agroalerta.ui.theme.AmberSoft
import com.frutis.agroalerta.ui.theme.AmberText
import com.frutis.agroalerta.ui.theme.BlueIcon
import com.frutis.agroalerta.ui.theme.BlueSoft
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedAlert
import com.frutis.agroalerta.ui.theme.RedSoft
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.TextSecondary
import java.util.Locale

/** Cabecera verde con logo de hoja (o flecha atrás), subtítulo de la empresa y campana. */
@Composable
fun AppHeader(
    title: String,
    subtitle: String = "AGRÍCOLA FRUTIS",
    onBack: (() -> Unit)? = null,
    onBellClick: (() -> Unit)? = null,
    showBellBadge: Boolean = false
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(GreenDark)
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = 0.14f))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                    .then(if (onBack != null) Modifier.clickable(onClick = onBack) else Modifier),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (onBack != null) Icons.AutoMirrored.Filled.ArrowBack else Icons.Outlined.Eco,
                    contentDescription = if (onBack != null) "Volver" else null,
                    tint = Color.White
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    subtitle,
                    color = Color(0xFFB9DDB7),
                    style = MaterialTheme.typography.labelSmall
                )
                Text(
                    title,
                    color = Color.White,
                    style = MaterialTheme.typography.titleLarge
                )
            }
            if (onBellClick != null) {
                Box {
                    IconButton(onClick = onBellClick) {
                        Icon(
                            Icons.Outlined.NotificationsNone,
                            contentDescription = "Notificaciones",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    if (showBellBadge) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = (-10).dp, y = 10.dp)
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(AmberAlert)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(Locale.getDefault()),
        color = GreenPrimary,
        style = MaterialTheme.typography.labelSmall,
        modifier = modifier
    )
}

/** Tarjeta "Modo Caché Local" que indica que se muestran las últimas lecturas conocidas. */
@Composable
fun CacheBanner(lastSync: String, offline: Boolean, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GreenSoft,
        border = BorderStroke(1.dp, GreenBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = GreenDark)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (offline) "Modo Caché Local" else "Conectado",
                    fontWeight = FontWeight.Bold,
                    color = GreenDark
                )
                Text("Última sincro: $lastSync", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            Surface(shape = RoundedCornerShape(8.dp), color = Color.White) {
                Text(
                    if (offline) "SIN COBERTURA" else "EN LÍNEA",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, letterSpacing = 0.5.sp),
                    color = GreenDark,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
        }
    }
}

fun SensorType.icon(): ImageVector = when (this) {
    SensorType.HUMEDAD_SUELO, SensorType.HUMEDAD_RELATIVA -> Icons.Outlined.WaterDrop
    SensorType.TEMPERATURA -> Icons.Outlined.Thermostat
    SensorType.RADIACION -> Icons.Outlined.WbSunny
    SensorType.NIVEL_ESTANQUE -> Icons.Outlined.Waves
    SensorType.CAUDAL -> Icons.Outlined.Speed
}

private fun SensorType.isWater(): Boolean =
    this == SensorType.HUMEDAD_SUELO || this == SensorType.HUMEDAD_RELATIVA ||
        this == SensorType.NIVEL_ESTANQUE || this == SensorType.CAUDAL

@Composable
fun SensorIconBox(type: SensorType, size: Int = 40) {
    val water = type.isWater()
    Box(
        Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (water) BlueSoft else GreenSoft),
        contentAlignment = Alignment.Center
    ) {
        Icon(type.icon(), contentDescription = null, tint = if (water) BlueIcon else GreenPrimary)
    }
}

fun formatValue(value: Double): String =
    if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.1f", value)

@Composable
fun SensorCard(reading: SensorReading, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder),
        modifier = modifier
    ) {
        Row(Modifier.padding(12.dp)) {
            SensorIconBox(reading.type)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        reading.type.label,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    StatusDot(reading.status)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold)) {
                            append(formatValue(reading.value))
                        }
                        withStyle(SpanStyle(fontSize = 11.sp, color = TextSecondary)) {
                            append(" ${reading.type.unit}")
                        }
                    }
                )
            }
        }
    }
}

fun SensorStatus.color(): Color = when (this) {
    SensorStatus.NORMAL -> GreenPrimary
    SensorStatus.ADVERTENCIA -> AmberAlert
    SensorStatus.CRITICO -> RedAlert
    SensorStatus.SIN_SENAL -> TextSecondary
}

@Composable
fun StatusDot(status: SensorStatus) {
    Box(
        Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(status.color())
    )
}

/** Etiqueta pequeña tipo "CRÍTICA", "Pendiente", "Caché local". */
@Composable
fun Tag(text: String, background: Color, foreground: Color, bold: Boolean = true, icon: ImageVector? = null) {
    Surface(shape = RoundedCornerShape(6.dp), color = background) {
        Row(
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = foreground, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text,
                fontSize = 11.sp,
                color = foreground,
                fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

fun Severity.colors(): Pair<Color, Color> = when (this) {
    Severity.CRITICA -> RedSoft to RedText
    Severity.ADVERTENCIA -> AmberSoft to AmberText
    Severity.INFORMATIVA -> BlueSoft to BlueIcon
}

@Composable
fun SeverityTag(severity: Severity) {
    val (bg, fg) = severity.colors()
    Tag(severity.label.uppercase(Locale.getDefault()), bg, fg)
}

/** Mensaje estándar para formularios que aún no están conectados a la plataforma central. */
@Composable
fun FutureUpdateDialog(onDismiss: () -> Unit, detail: String? = null) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.CloudOff, contentDescription = null, tint = GreenPrimary) },
        title = { Text("Para una futura actualización") },
        text = {
            Text(
                detail ?: "Esta funcionalidad estará disponible cuando la aplicación se conecte a la " +
                    "plataforma de supervisión mediante la API REST."
            )
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Entendido") } }
    )
}

@Composable
fun WhiteCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, CardBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            content()
        }
    }
}
