package com.frutis.agroalerta.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.frutis.agroalerta.data.PasswordHasher
import com.frutis.agroalerta.data.model.Role

@Database(entities = [UserEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao

    companion object {
        private const val DB_NAME = "agroalerta.db"

        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                ).addCallback(SeedCallback).build().also { instance = it }
            }

        /** Crea usuarios de demostración la primera vez que se crea la base de datos. */
        private object SeedCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                seedUser(db, "Supervisor Demo", "supervisor@frutis.cl", "super123", Role.SUPERVISOR)
                seedUser(db, "Técnico Demo", "tecnico@frutis.cl", "tecnico123", Role.TECNICO)
            }

            private fun seedUser(
                db: SupportSQLiteDatabase,
                name: String,
                email: String,
                password: String,
                role: Role
            ) {
                val salt = PasswordHasher.newSalt()
                db.execSQL(
                    "INSERT INTO users (full_name, email, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    arrayOf<Any>(
                        name,
                        email,
                        PasswordHasher.hash(password, salt),
                        salt,
                        role.name,
                        System.currentTimeMillis()
                    )
                )
            }
        }
    }
}
