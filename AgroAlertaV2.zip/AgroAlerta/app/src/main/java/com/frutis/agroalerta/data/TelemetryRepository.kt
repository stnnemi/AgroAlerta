package com.frutis.agroalerta.data

import com.frutis.agroalerta.data.model.Actuator
import com.frutis.agroalerta.data.model.ActuatorType
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.data.model.AlertCategory
import com.frutis.agroalerta.data.model.AlertStatus
import com.frutis.agroalerta.data.model.EventType
import com.frutis.agroalerta.data.model.HistoryEvent
import com.frutis.agroalerta.data.model.ReadingPoint
import com.frutis.agroalerta.data.model.SensorReading
import com.frutis.agroalerta.data.model.SensorStatus
import com.frutis.agroalerta.data.model.SensorType
import com.frutis.agroalerta.data.model.Severity
import com.frutis.agroalerta.data.model.Station
import kotlin.math.roundToInt

/**
 * Fuente de datos de telemetría del predio.
 *
 * En el MVP entrega datos representativos (ficticios) que simulan el caché local de las
 * últimas lecturas conocidas. En una futura versión se reemplaza por llamadas Retrofit a la
 * API REST de la plataforma de supervisión.
 */
class TelemetryRepository {

    val stations: List<Station> = listOf(
        Station("c1", "Cuartel 1", "Sur"),
        Station("c2", "Cuartel 2", "Oriente"),
        Station("c3", "Cuartel 3", "Norte"),
        Station("ep", "Estación principal", "Bombas")
    )

    val lastSync: String = "hace 5 min"

    private val baseReadings: Map<String, Map<SensorType, Double>> = mapOf(
        "c1" to mapOf(
            SensorType.HUMEDAD_SUELO to 58.0, SensorType.TEMPERATURA to 14.1,
            SensorType.HUMEDAD_RELATIVA to 76.0, SensorType.RADIACION to 310.0,
            SensorType.NIVEL_ESTANQUE to 64.0, SensorType.CAUDAL to 15.2
        ),
        "c2" to mapOf(
            SensorType.HUMEDAD_SUELO to 71.0, SensorType.TEMPERATURA to 13.4,
            SensorType.HUMEDAD_RELATIVA to 79.0, SensorType.RADIACION to 280.0,
            SensorType.NIVEL_ESTANQUE to 55.0, SensorType.CAUDAL to 17.0
        ),
        "c3" to mapOf(
            SensorType.HUMEDAD_SUELO to 67.0, SensorType.TEMPERATURA to 12.4,
            SensorType.HUMEDAD_RELATIVA to 81.0, SensorType.RADIACION to 245.0,
            SensorType.NIVEL_ESTANQUE to 42.0, SensorType.CAUDAL to 18.6
        ),
        "ep" to mapOf(
            SensorType.HUMEDAD_SUELO to 49.0, SensorType.TEMPERATURA to 15.0,
            SensorType.HUMEDAD_RELATIVA to 70.0, SensorType.RADIACION to 330.0,
            SensorType.NIVEL_ESTANQUE to 22.0, SensorType.CAUDAL to 3.8
        )
    )

    fun station(id: String): Station = stations.firstOrNull { it.id == id } ?: stations[2]

    fun readings(stationId: String, jitter: (SensorType) -> Double = { 0.0 }): List<SensorReading> {
        val base = baseReadings[stationId] ?: baseReadings.getValue("c3")
        return SensorType.entries.mapIndexed { index, type ->
            val value = round1(base.getValue(type) + jitter(type))
            SensorReading(
                type = type,
                value = value,
                status = statusFor(type, value),
                sensorCode = "${stationId.uppercase()}-S0${index + 1}",
                battery = 95 - index * 7,
                lastUpdate = "hace ${index % 3 + 1} min"
            )
        }
    }

    fun statusFor(type: SensorType, value: Double): SensorStatus {
        val margin = (type.max - type.min) * 0.1
        return when {
            value < type.min || value > type.max -> SensorStatus.CRITICO
            value < type.min + margin || value > type.max - margin -> SensorStatus.ADVERTENCIA
            else -> SensorStatus.NORMAL
        }
    }

    fun readingHistory(stationId: String, type: SensorType): List<ReadingPoint> {
        val base = (baseReadings[stationId] ?: baseReadings.getValue("c3")).getValue(type)
        val step = (type.max - type.min) * 0.03
        val offsets = listOf(4.0, 3.0, 2.5, 1.0, 0.5, -0.5, -1.0, 0.0)
        return offsets.mapIndexed { i, offset ->
            ReadingPoint(time = "%02d:00".format(i * 3), value = round1(base + offset * step))
        }
    }

    fun actuators(stationId: String): List<Actuator> {
        val frost = stationId == "c3"
        return listOf(
            Actuator("$stationId-ev1", "Electroválvula sector A", ActuatorType.ELECTROVALVULA, true, "Riego programado · 35 min"),
            Actuator("$stationId-ev2", "Electroválvula sector B", ActuatorType.ELECTROVALVULA, false, "Cerrada"),
            Actuator("$stationId-b1", "Bomba de impulsión", ActuatorType.BOMBA, stationId != "ep", "Presión 2,4 bar"),
            Actuator("$stationId-ah", "Sistema anti-heladas", ActuatorType.ANTIHELADA, frost, if (frost) "Aspersión activa" else "En espera")
        )
    }

    val alerts: List<Alert> = listOf(
        Alert(
            id = "a1",
            title = "Riesgo severo de helada",
            category = AlertCategory.HELADA,
            severity = Severity.CRITICA,
            location = "Cuartel 3",
            stationId = "c3",
            dayLabel = "Hoy",
            time = "04:15",
            status = AlertStatus.PENDIENTE,
            description = "La temperatura descendió bajo el umbral de seguridad y el pronóstico indica " +
                "valores bajo 0 °C antes del amanecer.",
            recommendation = "Verificar la activación del sistema anti-heladas y el caudal disponible " +
                "en el estanque.",
            relatedSensors = listOf(SensorType.TEMPERATURA, SensorType.HUMEDAD_RELATIVA, SensorType.NIVEL_ESTANQUE),
            cachedLocally = true
        ),
        Alert(
            id = "a2",
            title = "Fuga / obstrucción detectada",
            category = AlertCategory.FUGA,
            severity = Severity.CRITICA,
            location = "Bombas de impulsión",
            stationId = "ep",
            dayLabel = "Ayer",
            time = "18:42",
            status = AlertStatus.ATENDIDA,
            description = "Caudal fuera de rango en la estación principal mientras la bomba de " +
                "impulsión se encontraba activa.",
            recommendation = "Revisar filtros y matrices de riego; inspeccionar posibles roturas en la " +
                "línea principal.",
            relatedSensors = listOf(SensorType.CAUDAL, SensorType.NIVEL_ESTANQUE),
            cachedLocally = true
        ),
        Alert(
            id = "a3",
            title = "Nivel de estanque bajo",
            category = AlertCategory.NIVEL_AGUA,
            severity = Severity.ADVERTENCIA,
            location = "Estación principal",
            stationId = "ep",
            dayLabel = "Hoy",
            time = "02:30",
            status = AlertStatus.PENDIENTE,
            description = "El nivel del estanque se encuentra bajo el 25 % de su capacidad.",
            recommendation = "Programar llenado del estanque antes del próximo ciclo de riego.",
            relatedSensors = listOf(SensorType.NIVEL_ESTANQUE),
            cachedLocally = true
        ),
        Alert(
            id = "a4",
            title = "Humedad de suelo bajo el óptimo",
            category = AlertCategory.SENSOR,
            severity = Severity.ADVERTENCIA,
            location = "Cuartel 1",
            stationId = "c1",
            dayLabel = "Ayer",
            time = "15:10",
            status = AlertStatus.ATENDIDA,
            description = "La humedad de suelo se acercó al límite inferior configurado.",
            recommendation = "Evaluar adelantar el riego del sector.",
            relatedSensors = listOf(SensorType.HUMEDAD_SUELO),
            cachedLocally = false
        ),
        Alert(
            id = "a5",
            title = "Sincronización completada",
            category = AlertCategory.SISTEMA,
            severity = Severity.INFORMATIVA,
            location = "Plataforma central",
            stationId = "c3",
            dayLabel = "Hoy",
            time = "07:00",
            status = AlertStatus.ATENDIDA,
            description = "Se sincronizaron las últimas lecturas con la plataforma de supervisión.",
            recommendation = "Sin acciones requeridas.",
            relatedSensors = emptyList(),
            cachedLocally = false
        )
    )

    val history: List<HistoryEvent> = listOf(
        HistoryEvent("h1", EventType.ALERTA, "Hoy", "04:15", "Riesgo severo de helada", "Temperatura 0,8 °C · severidad crítica", "Cuartel 3"),
        HistoryEvent("h2", EventType.ACCION, "Hoy", "04:20", "Anti-heladas activado", "Acción automática del sistema local", "Cuartel 3"),
        HistoryEvent("h3", EventType.LECTURA, "Hoy", "04:00", "Lectura programada", "Temperatura 1,2 °C · HR 92 %", "Cuartel 3"),
        HistoryEvent("h4", EventType.ALERTA, "Hoy", "02:30", "Nivel de estanque bajo", "Nivel 22 % · severidad advertencia", "Estación principal"),
        HistoryEvent("h5", EventType.LECTURA, "Hoy", "00:00", "Lectura programada", "Humedad suelo 66 % · Caudal 18,1 L/s", "Cuartel 2"),
        HistoryEvent("h6", EventType.ACCION, "Ayer", "19:05", "Alerta atendida", "Fuga / obstrucción · registrada por Supervisor", "Bombas de impulsión"),
        HistoryEvent("h7", EventType.ALERTA, "Ayer", "18:42", "Fuga / obstrucción detectada", "Caudal 3,8 L/s fuera de rango", "Bombas de impulsión"),
        HistoryEvent("h8", EventType.ALERTA, "Ayer", "15:10", "Humedad de suelo bajo el óptimo", "Humedad suelo 33 %", "Cuartel 1"),
        HistoryEvent("h9", EventType.LECTURA, "Ayer", "12:00", "Lectura programada", "Radiación 920 W/m² · Temp. 24,3 °C", "Cuartel 1")
    )

    private fun round1(value: Double): Double = (value * 10).roundToInt() / 10.0
}
