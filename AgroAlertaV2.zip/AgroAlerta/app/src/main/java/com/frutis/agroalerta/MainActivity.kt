package com.frutis.agroalerta

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.frutis.agroalerta.ui.navigation.AgroAlertaRoot
import com.frutis.agroalerta.ui.notification.NotificationHelper
import com.frutis.agroalerta.ui.theme.AgroAlertaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        setContent {
            AgroAlertaTheme {
                AgroAlertaRoot()
            }
        }
    }
}
