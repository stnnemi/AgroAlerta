package com.frutis.agroalerta.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.frutis.agroalerta.data.model.EventType
import com.frutis.agroalerta.data.model.HistoryEvent
import com.frutis.agroalerta.ui.components.AppHeader
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.components.SectionLabel
import com.frutis.agroalerta.ui.components.WhiteCard
import com.frutis.agroalerta.ui.theme.BlueIcon
import com.frutis.agroalerta.ui.theme.BlueSoft
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedSoft
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.ScreenBg
import com.frutis.agroalerta.ui.theme.TextSecondary

private fun EventType.style(): Triple<ImageVector, Color, Color> = when (this) {
    EventType.ALERTA -> Triple(Icons.Outlined.WarningAmber, RedSoft, RedText)
    EventType.LECTURA -> Triple(Icons.Outlined.Sensors, BlueSoft, BlueIcon)
    EventType.ACCION -> Triple(Icons.Outlined.Build, GreenSoft, GreenPrimary)
}

@Composable
fun HistoryScreen(events: List<HistoryEvent>, onBellClick: () -> Unit, showBadge: Boolean) {
    var filter by rememberSaveable { mutableStateOf<EventType?>(null) }
    var showFilterForm by rememberSaveable { mutableStateOf(false) }
    var showFutureUpdate by rememberSaveable { mutableStateOf(false) }

    val filtered = events.filter { filter == null || it.type == filter }

    Column(
        Modifier
            .fillMaxSize()
            .background(ScreenBg)
    ) {
        AppHeader(title = "Historial", onBellClick = onBellClick, showBellBadge = showBadge)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel("Trazabilidad")
            Text("Eventos y lecturas recientes", style = MaterialTheme.typography.headlineSmall)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showFilterForm = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.FilterList, null, tint = GreenDark, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Filtrar fechas", color = GreenDark)
                }
                OutlinedButton(onClick = { showFutureUpdate = true }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Download, null, tint = GreenDark, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Exportar", color = GreenDark)
                }
            }

            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = filter == null,
                    onClick = { filter = null },
                    label = { Text("Todos") },
                    colors = chipColors()
                )
                EventType.entries.forEach { type ->
                    FilterChip(
                        selected = filter == type,
                        onClick = { filter = type },
                        label = { Text(type.label) },
                        colors = chipColors()
                    )
                }
            }

            filtered.groupBy { it.dayLabel }.forEach { (day, dayEvents) ->
                Text(day, style = MaterialTheme.typography.titleMedium)
                WhiteCard {
                    dayEvents.forEachIndexed { index, event ->
                        EventRow(event)
                        if (index < dayEvents.lastIndex) HorizontalDivider(color = CardBorder)
                    }
                }
            }
            if (filtered.isEmpty()) {
                Text("Sin eventos para este filtro.", color = TextSecondary)
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showFilterForm) {
        DateFilterDialog(
            onDismiss = { showFilterForm = false },
            onApply = {
                showFilterForm = false
                showFutureUpdate = true
            }
        )
    }
    if (showFutureUpdate) {
        FutureUpdateDialog(onDismiss = { showFutureUpdate = false })
    }
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    selectedContainerColor = GreenPrimary,
    selectedLabelColor = Color.White,
    containerColor = Color.White
)

@Composable
private fun EventRow(event: HistoryEvent) {
    val (icon, bg, fg) = event.type.style()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(event.title, fontWeight = FontWeight.Medium)
            Text(event.detail, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(event.station, style = MaterialTheme.typography.bodySmall, color = GreenPrimary)
        }
        Text(event.time, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
private fun DateFilterDialog(onDismiss: () -> Unit, onApply: () -> Unit) {
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }
    val datePattern = Regex("""\d{2}/\d{2}/\d{4}""")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Filtrar por fechas") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = from,
                    onValueChange = { from = it; error = null },
                    label = { Text("Desde (dd/mm/aaaa)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = to,
                    onValueChange = { to = it; error = null },
                    label = { Text("Hasta (dd/mm/aaaa)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, color = RedText, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                error = if (!datePattern.matches(from) || !datePattern.matches(to)) "Usa el formato dd/mm/aaaa" else null
                if (error == null) onApply()
            }) { Text("Aplicar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
