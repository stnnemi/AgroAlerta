package com.frutis.agroalerta.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.SupervisorAccount
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role as SemanticsRole
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.frutis.agroalerta.data.model.Role
import com.frutis.agroalerta.ui.components.FutureUpdateDialog
import com.frutis.agroalerta.ui.theme.CardBorder
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedSoft
import com.frutis.agroalerta.ui.theme.RedText
import com.frutis.agroalerta.ui.theme.TextSecondary

@Composable
private fun AuthBackground(content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GreenDark, Color(0xFF0F2E10))))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Eco, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("AgroAlerta", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("AGRÍCOLA FRUTIS", color = Color(0xFFB9DDB7), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(24.dp))
            Surface(shape = RoundedCornerShape(24.dp), color = Color.White, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    content()
                }
            }
        }
    }
}

@Composable
private fun ErrorBox(message: String) {
    Surface(shape = RoundedCornerShape(10.dp), color = RedSoft, modifier = Modifier.fillMaxWidth()) {
        Text(message, color = RedText, modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun PasswordField(value: String, onChange: (String) -> Unit, label: String, imeAction: ImeAction = ImeAction.Done) {
    var visible by rememberSaveable { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(
                    if (visible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                    contentDescription = if (visible) "Ocultar contraseña" else "Mostrar contraseña"
                )
            }
        },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = imeAction),
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PrimaryButton(text: String, loading: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = !loading,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = GreenPrimary),
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
    ) {
        if (loading) {
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        } else {
            Text(text, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun LoginScreen(viewModel: SessionViewModel, onGoToRegister: () -> Unit) {
    val form by viewModel.form.collectAsStateWithLifecycle()
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var showForgot by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(Unit) { viewModel.clearError() }

    AuthBackground {
        Text("Iniciar sesión", style = MaterialTheme.typography.titleLarge)
        Text(
            "Monitorea el estado del predio y las alertas críticas desde terreno.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )
        PasswordField(password, { password = it }, "Contraseña")
        TextButton(onClick = { showForgot = true }, modifier = Modifier.align(Alignment.End)) {
            Text("¿Olvidaste tu contraseña?", color = GreenPrimary)
        }
        form.error?.let { ErrorBox(it) }
        PrimaryButton("Ingresar", form.loading) { viewModel.login(email, password) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Text("¿No tienes cuenta?", color = TextSecondary)
            TextButton(onClick = onGoToRegister) { Text("Regístrate", color = GreenPrimary, fontWeight = FontWeight.Bold) }
        }
        Surface(shape = RoundedCornerShape(10.dp), color = GreenSoft, modifier = Modifier.fillMaxWidth()) {
            Text(
                "Cuentas de prueba\nSupervisor: supervisor@frutis.cl / super123\nTécnico: tecnico@frutis.cl / tecnico123",
                style = MaterialTheme.typography.bodySmall,
                color = GreenDark,
                modifier = Modifier.padding(10.dp)
            )
        }
    }

    if (showForgot) {
        FutureUpdateDialog(
            onDismiss = { showForgot = false },
            detail = "La recuperación de contraseña se habilitará cuando la app se conecte a la plataforma central."
        )
    }
}

@Composable
fun RegisterScreen(viewModel: SessionViewModel, onBackToLogin: () -> Unit) {
    val form by viewModel.form.collectAsStateWithLifecycle()
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var role by rememberSaveable { mutableStateOf<Role?>(null) }

    LaunchedEffect(Unit) { viewModel.clearError() }

    AuthBackground {
        Text("Crear cuenta", style = MaterialTheme.typography.titleLarge)
        Text(
            "Tu cuenta se guarda de forma segura en el dispositivo (modo offline).",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nombre completo") },
            leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        )
        PasswordField(password, { password = it }, "Contraseña (mín. 6 caracteres)", ImeAction.Next)
        PasswordField(confirm, { confirm = it }, "Confirmar contraseña")

        Text("Tipo de usuario", style = MaterialTheme.typography.titleMedium)
        RoleOption(Role.SUPERVISOR, Icons.Outlined.SupervisorAccount, role == Role.SUPERVISOR) { role = Role.SUPERVISOR }
        RoleOption(Role.TECNICO, Icons.Outlined.Sensors, role == Role.TECNICO) { role = Role.TECNICO }

        form.error?.let { ErrorBox(it) }
        PrimaryButton("Registrarme", form.loading) { viewModel.register(name, email, password, confirm, role) }
        TextButton(onClick = onBackToLogin, modifier = Modifier.fillMaxWidth()) {
            Text("Ya tengo cuenta · Iniciar sesión", color = GreenPrimary, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun RoleOption(role: Role, icon: ImageVector, selected: Boolean, onSelect: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) GreenSoft else Color.White,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) GreenPrimary else CardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onSelect, role = SemanticsRole.RadioButton)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = GreenPrimary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(role.label, fontWeight = FontWeight.Bold)
                Text(role.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            RadioButton(selected = selected, onClick = null)
        }
    }
}

/** Pantalla breve mientras se restaura la sesión guardada. */
@Composable
fun SplashScreen() {
    Box(
        Modifier
            .fillMaxSize()
            .background(GreenDark),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Outlined.Eco, contentDescription = null, tint = Color.White, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(12.dp))
            Text("AgroAlerta", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
        }
    }
}

