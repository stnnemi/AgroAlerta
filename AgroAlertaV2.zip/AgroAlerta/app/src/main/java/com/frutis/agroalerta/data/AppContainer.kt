package com.frutis.agroalerta.data

import android.content.Context
import com.frutis.agroalerta.data.local.AppDatabase

/** Contenedor manual de dependencias compartidas por toda la app. */
class AppContainer(context: Context) {
    private val database = AppDatabase.getInstance(context)
    val sessionManager = SessionManager(context)
    val authRepository = AuthRepository(database.userDao(), sessionManager)
    val telemetryRepository = TelemetryRepository()
}
