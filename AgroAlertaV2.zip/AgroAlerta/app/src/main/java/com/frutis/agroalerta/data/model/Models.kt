package com.frutis.agroalerta.data.model

enum class Role(val label: String, val description: String) {
    SUPERVISOR("Supervisor", "Acceso completo: telemetría, actuadores, alertas e historial"),
    TECNICO("Técnico", "Solo lectura del estado de los sensores");

    companion object {
        fun fromName(name: String): Role = entries.firstOrNull { it.name == name } ?: TECNICO
    }
}

data class Station(val id: String, val name: String, val zone: String) {
    val displayName: String get() = "$name · $zone"
}

enum class SensorType(val label: String, val unit: String, val min: Double, val max: Double) {
    HUMEDAD_SUELO("Humedad suelo", "%", 30.0, 85.0),
    TEMPERATURA("Temperatura", "°C", 2.0, 32.0),
    HUMEDAD_RELATIVA("Humedad relativa", "%", 40.0, 95.0),
    RADIACION("Radiación solar", "W/m²", 0.0, 1100.0),
    NIVEL_ESTANQUE("Nivel estanque", "%", 25.0, 100.0),
    CAUDAL("Caudal", "L/s", 5.0, 30.0)
}

enum class SensorStatus(val label: String) {
    NORMAL("Operativo"),
    ADVERTENCIA("Advertencia"),
    CRITICO("Crítico"),
    SIN_SENAL("Sin señal")
}

data class SensorReading(
    val type: SensorType,
    val value: Double,
    val status: SensorStatus,
    val sensorCode: String,
    val battery: Int,
    val lastUpdate: String
)

data class ReadingPoint(val time: String, val value: Double)

enum class ActuatorType { ELECTROVALVULA, BOMBA, ANTIHELADA }

data class Actuator(
    val id: String,
    val name: String,
    val type: ActuatorType,
    val isOn: Boolean,
    val detail: String
)

enum class Severity(val label: String) {
    CRITICA("Crítica"),
    ADVERTENCIA("Advertencia"),
    INFORMATIVA("Informativa")
}

enum class AlertCategory(val label: String) {
    HELADA("Helada"),
    FUGA("Fuga / Obstrucción"),
    NIVEL_AGUA("Nivel de agua"),
    SENSOR("Sensor"),
    SISTEMA("Sistema")
}

enum class AlertStatus(val label: String) {
    PENDIENTE("Pendiente"),
    ATENDIDA("Atendida")
}

data class Alert(
    val id: String,
    val title: String,
    val category: AlertCategory,
    val severity: Severity,
    val location: String,
    val stationId: String,
    val dayLabel: String,
    val time: String,
    val status: AlertStatus,
    val description: String,
    val recommendation: String,
    val relatedSensors: List<SensorType>,
    val cachedLocally: Boolean
)

enum class EventType(val label: String) {
    ALERTA("Alertas"),
    LECTURA("Lecturas"),
    ACCION("Acciones")
}

data class HistoryEvent(
    val id: String,
    val type: EventType,
    val dayLabel: String,
    val time: String,
    val title: String,
    val detail: String,
    val station: String
)
