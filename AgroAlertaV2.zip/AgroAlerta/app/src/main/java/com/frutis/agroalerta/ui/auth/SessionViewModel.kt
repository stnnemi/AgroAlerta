package com.frutis.agroalerta.ui.auth

import android.util.Patterns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.frutis.agroalerta.data.AuthRepository
import com.frutis.agroalerta.data.local.UserEntity
import com.frutis.agroalerta.data.model.Role
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SessionState(
    val restoring: Boolean = true,
    val user: UserEntity? = null
)

data class AuthFormState(
    val loading: Boolean = false,
    val error: String? = null
)

/** Gestiona el registro, inicio y cierre de sesión contra la base de datos SQLite local. */
class SessionViewModel(private val repository: AuthRepository) : ViewModel() {

    private val _session = MutableStateFlow(SessionState())
    val session: StateFlow<SessionState> = _session.asStateFlow()

    private val _form = MutableStateFlow(AuthFormState())
    val form: StateFlow<AuthFormState> = _form.asStateFlow()

    val registeredUsers: StateFlow<List<UserEntity>> = repository.users
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            _session.value = SessionState(restoring = false, user = repository.currentUser())
        }
    }

    fun clearError() = _form.update { it.copy(error = null) }

    fun login(email: String, password: String) {
        val error = when {
            email.isBlank() || password.isBlank() -> "Ingresa tu correo y contraseña"
            !isValidEmail(email) -> "El correo no tiene un formato válido"
            else -> null
        }
        if (error != null) {
            _form.value = AuthFormState(error = error)
            return
        }
        viewModelScope.launch {
            _form.value = AuthFormState(loading = true)
            repository.login(email, password)
                .onSuccess { user ->
                    _form.value = AuthFormState()
                    _session.value = SessionState(restoring = false, user = user)
                }
                .onFailure { _form.value = AuthFormState(error = it.message ?: "No fue posible iniciar sesión") }
        }
    }

    fun register(fullName: String, email: String, password: String, confirm: String, role: Role?) {
        val error = when {
            fullName.trim().length < 3 -> "Ingresa tu nombre completo"
            !isValidEmail(email) -> "El correo no tiene un formato válido"
            password.length < 6 -> "La contraseña debe tener al menos 6 caracteres"
            password != confirm -> "Las contraseñas no coinciden"
            role == null -> "Selecciona un tipo de usuario"
            else -> null
        }
        if (error != null) {
            _form.value = AuthFormState(error = error)
            return
        }
        viewModelScope.launch {
            _form.value = AuthFormState(loading = true)
            repository.register(fullName, email, password, role!!)
                .onSuccess { user ->
                    _form.value = AuthFormState()
                    _session.value = SessionState(restoring = false, user = user)
                }
                .onFailure { _form.value = AuthFormState(error = it.message ?: "No fue posible registrar la cuenta") }
        }
    }

    fun logout() {
        repository.logout()
        _form.value = AuthFormState()
        _session.value = SessionState(restoring = false, user = null)
    }

    private fun isValidEmail(email: String): Boolean =
        Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
}
