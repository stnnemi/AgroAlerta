package com.frutis.agroalerta.ui.notification

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.frutis.agroalerta.data.model.Alert
import com.frutis.agroalerta.ui.alerts.icon
import com.frutis.agroalerta.ui.components.Tag
import com.frutis.agroalerta.ui.components.colors
import com.frutis.agroalerta.ui.theme.GreenAccent
import com.frutis.agroalerta.ui.theme.GreenDark
import com.frutis.agroalerta.ui.theme.GreenPrimary
import com.frutis.agroalerta.ui.theme.GreenSoft
import com.frutis.agroalerta.ui.theme.RedAlert
import com.frutis.agroalerta.ui.theme.TextSecondary
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Vista previa de la notificación crítica tal como se vería en la pantalla de bloqueo de Android. */
@Composable
fun CriticalNotificationScreen(
    alert: Alert,
    onOpenInApp: () -> Unit,
    onAccept: () -> Unit,
    onBack: () -> Unit
) {
    val now = remember { LocalDateTime.now() }
    val locale = Locale.forLanguageTag("es-CL")
    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale))
        .replaceFirstChar { it.titlecase(locale) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF2F5A3A), Color(0xFF0E2416)), radius = 1600f))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(32.dp))
            Text(time, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
            Text(date, color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp)
            Spacer(Modifier.height(28.dp))

            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFF4F5F3), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(GreenPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Outlined.Eco, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("AgroAlerta", fontWeight = FontWeight.Bold)
                        Text("  ahora", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Icon(Icons.Outlined.WarningAmber, contentDescription = null, tint = RedAlert)
                    }
                    Row(Modifier.padding(horizontal = 14.dp)) {
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(RedAlert),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(alert.category.icon(), null, tint = Color.White)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                "${alert.location} · ${alert.description}",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                maxLines = 2
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                val (bg, fg) = alert.severity.colors()
                                Tag("PRIORIDAD ${alert.severity.label.uppercase(Locale.getDefault())}", bg, fg)
                                if (alert.cachedLocally) {
                                    Tag("Guardada localmente", GreenSoft, GreenDark, icon = Icons.Outlined.CloudOff)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth().height(52.dp)) {
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .background(Color.White)
                                .clickable(onClick = onOpenInApp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Ver en App", fontWeight = FontWeight.Bold, color = GreenDark)
                        }
                        Box(
                            Modifier
                                .weight(1f)
                                .fillMaxSize()
                                .background(GreenAccent)
                                .clickable(onClick = onAccept),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Aceptar Alerta", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.NotificationsNone, null, tint = Color.White)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Notificación crítica de Android", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "Acciones rápidas disponibles aun con la pantalla bloqueada",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = Color.White.copy(alpha = 0.1f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                modifier = Modifier.clickable(onClick = onBack)
            ) {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Volver a AgroAlerta", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.weight(1f))
            Icon(Icons.Outlined.Eco, null, tint = Color.White.copy(alpha = 0.8f))
            Text(
                "Desliza hacia arriba para desbloquear",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
    }
}

