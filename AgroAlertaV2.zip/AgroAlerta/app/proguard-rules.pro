# Reglas ProGuard del proyecto (minify desactivado en el MVP).
