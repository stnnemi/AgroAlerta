# AgroAlerta · Agrícola FRUTIS

MVP móvil (DSY1105) para monitorear la telemetría del predio y las alertas críticas
(heladas, fugas/obstrucciones y nivel de agua) desde terreno.

**Stack:** Kotlin · Android Studio · Jetpack Compose · Material Design 3 · MVVM · Room (SQLite) · Navigation Compose.

## Cómo ejecutar

1. Abrir la carpeta del proyecto en Android Studio (Ladybug o superior).
   Si pide elegir la JVM de Gradle, seleccionar **JVM 21** (Gradle 8.11 no admite Java 25).
2. Esperar la sincronización de Gradle (AGP 8.7, Kotlin 2.0, compileSdk 35, minSdk 26).
3. Ejecutar la configuración `app` en un emulador o dispositivo.

Para el APK firmado: *Build → Generate Signed App Bundle / APK → APK → release*.

## Autenticación (SQLite local, funcional)

- Registro e inicio de sesión contra una base de datos local `agroalerta.db` (Room sobre SQLite).
- Las contraseñas se guardan como hash SHA-256 con sal aleatoria (nunca en texto plano).
- La sesión se recuerda entre aperturas de la app hasta que el usuario cierra sesión.
- Al crear la base de datos se generan dos cuentas de prueba:

| Rol        | Correo                 | Contraseña  |
|------------|------------------------|-------------|
| Supervisor | supervisor@frutis.cl   | super123    |
| Técnico    | tecnico@frutis.cl      | tecnico123  |

## Roles

| Funcionalidad                                  | Supervisor | Técnico |
|------------------------------------------------|:----------:|:-------:|
| Telemetría de sensores y detalle de sensor     | ✔          | ✔       |
| Diagnóstico de estado de sensores              |            | ✔       |
| Alertas activas, detalle y aceptación          | ✔          |         |
| Notificación crítica (pantalla de bloqueo/push)| ✔          |         |
| Estado y control de actuadores                 | ✔          |         |
| Historial de eventos                           | ✔          |         |
| Reporte en terreno / umbrales                  | ✔          |         |
| Usuarios registrados (BD local)                | ✔          |         |
| Perfil, editar perfil, cambiar contraseña      | ✔          | ✔       |

Si un técnico intenta abrir una ruta exclusiva del supervisor se muestra *Acceso restringido*.

## Pantallas

- **Login / Registro** (con selección de tipo de usuario).
- **Inicio · Estado del predio**: modo caché local, estación activa (cambiar cuartel), alerta activa,
  telemetría en vivo (humedad suelo, temperatura, humedad relativa, radiación, nivel estanque, caudal),
  actuadores y acciones rápidas.
- **Detalle de sensor**: lectura actual, rango, tendencia de 24 h e historial.
- **Alertas**: filtros Críticas / Advertencias / Informativas y por tipo (helada, fuga, nivel de agua).
- **Detalle de alerta**: lecturas asociadas, aceptar alerta, simular notificación push y formulario
  *Registrar acción tomada*.
- **Notificación crítica**: vista de pantalla de bloqueo con *Ver en App* / *Aceptar Alerta*
  (además publica una notificación real del sistema en el canal "Alertas críticas").
- **Historial**: eventos agrupados por día, filtros por tipo, filtrar por fechas y exportar.
- **Reporte en terreno**, **Configurar umbrales**, **Editar perfil**, **Cambiar contraseña**.
- **Perfil** y **Usuarios registrados**.

Los formularios validan los datos y, como aún no están conectados a la plataforma central (API REST),
muestran el mensaje **"Para una futura actualización"**. Los datos de telemetría son ficticios y
representan el caché local de las últimas lecturas conocidas.

## Alcance de esta entrega

| Elemento | Estado |
|----------|--------|
| Autenticación local (Room/SQLite: `UserDao`, `AppDatabase`, `PasswordHasher`) | Implementado y 100 % funcional: único módulo con persistencia real. |
| Formularios (`FormScreens.kt`, registrar acción, filtros de historial) | Implementados: validan los campos y al presionar *Guardar/Enviar* muestran **"Para una futura actualización"**. |
| Integración Retrofit / API REST (Spring Boot) | Pendiente para una próxima entrega. No hay conexión a servicios externos. |
| Caché Room de telemetría | Pendiente para una próxima entrega. Las lecturas son datos de ejemplo en memoria. |

## Estructura

```
AgroAlerta/
├── app/                  # módulo de la aplicación
├── gradle/               # libs.versions.toml + wrapper (gradle-wrapper.jar/.properties)
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew / gradlew.bat # único wrapper de Gradle, en la raíz
└── README.md

app/src/main/java/com/frutis/agroalerta/
├── data/            # Room (UserEntity, UserDao, AppDatabase), AuthRepository, SessionManager,
│                    # PasswordHasher, TelemetryRepository (datos simulados), modelos
└── ui/              # Compose: theme, components, navigation, auth, home, sensor, alerts,
                     # notification, history, forms, profile + ViewModels (MVVM)
```
